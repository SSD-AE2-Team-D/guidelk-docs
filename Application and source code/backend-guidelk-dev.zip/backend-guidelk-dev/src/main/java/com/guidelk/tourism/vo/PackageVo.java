package com.guidelk.tourism.vo;

import java.util.Date;

public class PackageVo {
    private Integer packageType;
    private Integer hotelId;
    private Date startDate;
    private Date endDate;
}
