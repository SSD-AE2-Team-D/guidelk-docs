package com.guidelk.tourism.auth.payload.request;

public class LogOutRequest {
    private Integer userId;

    public Integer getUserId() {
        return userId;
    }

}
