INSERT INTO public.organization_modules (organization_id, module_id) VALUES (1, 65);
INSERT INTO public.organization_modules (organization_id, module_id) VALUES (1, 64);
INSERT INTO public.organization_modules (organization_id, module_id) VALUES (1, 1);
INSERT INTO public.organization_modules (organization_id, module_id) VALUES (1, 66);