export const environment = {
  production: true,
  apiUrl: 'http://52.139.220.95:8085/',
};
