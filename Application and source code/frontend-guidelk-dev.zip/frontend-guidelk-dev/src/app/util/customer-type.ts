export class CustomerType {
    customerTypeId: number;
    customerDescription: string;
}