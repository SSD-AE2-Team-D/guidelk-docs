export class SharedModel {
    createdBy: string;
    createdDate: Date;
    lastModifiedBy: string;
    lastModifiedDate: Date;
    status: number;
    statusDescription: string;


}