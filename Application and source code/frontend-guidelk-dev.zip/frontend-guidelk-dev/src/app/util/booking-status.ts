export class BookingStatus{
    bookingStatusId: number;
    bookingStatusDescription: string;
}