export class HotelCategoryType {
    categoryId: number;
    categoryDescription: string;
}