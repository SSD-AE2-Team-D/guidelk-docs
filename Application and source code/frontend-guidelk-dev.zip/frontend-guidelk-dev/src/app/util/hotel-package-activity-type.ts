export class HotelPackageActivityType{
    activityTypeId: number;
    activityDescription: string;
}