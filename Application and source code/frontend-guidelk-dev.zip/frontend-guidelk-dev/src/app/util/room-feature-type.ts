export class RoomFeatureType{
    featureTypeId: number;
    featureDescription: string;

}