export class GenderType{
    genderTypeId: number;
    genderDescription: string;
}