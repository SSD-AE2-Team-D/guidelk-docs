export class MasterStatus {
    statusSeq: number;
    status: string;
}