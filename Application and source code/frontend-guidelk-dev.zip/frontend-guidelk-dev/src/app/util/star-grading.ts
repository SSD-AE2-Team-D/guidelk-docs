export class StarGrading{
    starGradingId: number;
    starGradingDescription: string;
}