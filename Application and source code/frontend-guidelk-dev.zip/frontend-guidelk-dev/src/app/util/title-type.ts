export class TitleType{
    titleTypeId: number;
    titleDescription: string;
}