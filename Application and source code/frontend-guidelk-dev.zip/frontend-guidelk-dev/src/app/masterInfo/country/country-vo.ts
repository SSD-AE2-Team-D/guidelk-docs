export class CountryVo {
    countryName: string;
    countryCode: string;
    status: number;
}