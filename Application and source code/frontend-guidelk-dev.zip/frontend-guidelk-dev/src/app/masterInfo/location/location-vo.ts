export class LocationVo {
    locationName: string;
    locationCode: string;
    countryId: number;
    status: number;
}