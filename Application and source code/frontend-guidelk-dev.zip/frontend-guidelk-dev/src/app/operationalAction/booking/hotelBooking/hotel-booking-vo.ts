export class HotelBookingVo {
    bookingNumber: string;
    hotelId: number;
    customerId: number;
    roomTypeId: number;
    activityTypeId: number;
    bookingStatus: number;
    checkInDate: Date;
    checkOutDate: Date;
    status: number;
    organizationId: number;
}