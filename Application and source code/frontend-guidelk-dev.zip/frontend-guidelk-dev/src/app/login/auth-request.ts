export class AuthRequest{
    userName: string;
    password: string;
}
