export class HotelPackageVo {
    packageName: string;
    hotelId: number;
    roomTypeId: number;
    activityTypeId: number;
    startDate: Date;
    endDate: Date;
    status: number;
    organizationId: number;
}