export class HotelVo {
    hotelName: string;
    categoryId: number;
    starGradingId: number;
    organizationId: number;
    countryId: number;
    locationId: number;
    status: number;
}