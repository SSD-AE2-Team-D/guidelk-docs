export class RoomTypeUniqueFind{
    roomType: string;
}