export class CustomerVo {
    firstName: string;
    lastName: string;
    passportNumber: string;
    identificationNumber: string;
    occupation: string;
    titleTypeId: number;
    genderTypeId: number;
    customerTypeId: number;
    organizationId: number;
    countryId: number;
    locationId: number;
    status: number;
}