export class PageVo {
    pageName: string;
    moduleId: number;
    status: number;
    createdFromDate: Date;
    createdToDate: Date;

}