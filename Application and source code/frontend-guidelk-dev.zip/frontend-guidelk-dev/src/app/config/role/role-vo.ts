export class RoleVo {
    roleName: string;
    status: null;
    createdFromDate: Date;
    createdToDate: Date;
}