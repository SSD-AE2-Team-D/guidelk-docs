export class ModuleVo {
    moduleName: string;
    moduleCode: string;
    status: number;
    organizationId: number;
    createdFromDate: Date;
    createdToDate: Date;
}