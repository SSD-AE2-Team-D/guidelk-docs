export class UserVo {
    userName: string;
    organizationId: number;
    status: number;
    createdFromDate: Date;
    createdToDate: Date;
}