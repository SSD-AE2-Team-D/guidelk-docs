export class OrganizationVo {
    organizationName: string;
    status: number;
    createdFromDate: Date;
    createdToDate: Date;
}